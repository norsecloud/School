1. Open up stack.java and Project2.java into ecclipse
2. press run 
3. enter a formula to turn from infix to postfix notation