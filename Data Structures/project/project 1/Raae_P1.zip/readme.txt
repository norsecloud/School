This Readme.txt is how to compile and run list.java and Mp3Player.java in eclipse ide

1. Make a new project and copy list.java and Mp3Player.java into default packages folder in the src folder

2. drag and drop the music in project1_files into the default packages as well

3. Right Click on project name then go to Build path>configure build path new window opens up inside java build path in properties click on libraries then add external jars
navigate to project1_files and click on jl1.0.1.jar
This step adds the javazoom libraries needed to play the mp3player

4. Save the .java files and run them starting with list.java then Mp3Player.java
